#ifndef basic_H
#define basic_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#define TRUE 1
#define FALSE 0
#define MAX_arg_Num 100
#define MAX_arg_Buf 200
#define MAX_Buffer 1000
#define MAX_Name 20
#define INSERT 101
#define DELETE 102
#define SWAP 103
#define PRINT_ID 104
#define PRINT_NAME 105
#define RESULT 106
#endif
