#ifndef basic_H
#define basic_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1
#define FALSE 0
#define MAX_person 1000
typedef int BOOL;
#endif